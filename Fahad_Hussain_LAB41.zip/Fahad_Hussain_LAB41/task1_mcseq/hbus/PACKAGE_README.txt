* Title:            Package for the HBUS bus protocol.
* Name:             hbus
* Version:          0.1 
* Created:          Sun Feb 15 11:02:20 2009
* Support:          meade@cadence.com
* Description:
 
This is the HBUS UVC.  The HBUS is a basic read/write bus protocol
implemented in UVM

* Directory structure:

This package contains the following directories: 

  sv/ - All SystemVerilog source files
  tb/ - Verification Environment example        

